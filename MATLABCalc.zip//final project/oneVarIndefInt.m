function [out] = oneVarIndefInt(input, var)
%see bottom section of oneVarDefInt for explanation of what this is and
%does. It's the same code, just without a and b in the integral
eqn = extractBetween(input, ":", ":");
if( strcmp(var, "x") == 1)
        x = sym('x');
        out = int(eqn,x);
    elseif( strcmp(var, "y") == 1)
        y =  sym('y');
        out = int(eqn,y);
    elseif( strcmp(var, "z") == 1)
        z = sym('z');
        out = int(eqn,z);
end
end