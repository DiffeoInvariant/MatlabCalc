function [out] = typeOfProblem(IP)
%determine what sort of problem this is
%use strfind(IP, string to search for)
%return the solution to the problem by directing to another function
 
 
%what are the variables
eqn = extractBetween(IP, ":",":");
deriv = contains(IP, "derivative");
 seri = contains(IP, "series");
 sm = contains(IP,"sum");
 inte = contains(IP, "integrate");
%finds all possible uses of x,y, and z as variables.
varsx = contains(eqn, "x");
varsy = contains(eqn, "y");
varsz = contains(eqn, "z");
afprob = extractAfter(IP, eqn);
varsNum = [0,0,0];
        varCt = 0;
        for k = 1:23
            if varsx == 1 || varsNum(1)==1
                varsNum(1) = 1;
            end
            if varsy == 1 || varsNum(2)==1
                varsNum(2) = 1;
            end
            if varsz == 1 || varsNum(3)==1
                varsNum(3) = 1;
            end
        end
        %increments varCt to the number of variables there are
        for l = 1:3
            if varsNum(l) == 1
                varCt = varCt+1;
            end
        end
        if varCt == 0
            disp("Please make sure you're only using x, y, and z as variables (no other variables), and have :colons: surrounding your equation");
        end
%finds what sort of problem we're doing (main part of the funtion)
if (deriv == 1  && varCt == 1)
    %if the problem mentions derivative and there is only one var
    if contains(eqn, "x")
            out = derivative(IP, "x");
        elseif contains(afprob, "y")
            out = derivative(IP, "y");
        else
            out = derivative(IP, "z");
    end
elseif deriv == 1 && varCt ~= 1
    %if the problem mentions derivative and there are
    %multiple variables
        if contains(afprob, "x")
            out = partialDiff(IP, "x");
        elseif contains(afprob, "y")
            out = partialDiff(IP, "y");
        else
            out = partialDiff(IP, "z");
        end
    
elseif( inte == 1 && varCt == 1 )
    %if it mentions integrals and has one variable
    if(contains(afprob, "from")==0)
        if( varsx == 1)
            out = oneVarIndefInt(IP, "x");
        elseif(varsy == 1)
            out = oneVarIndefInt(IP, "y");
        elseif(varsz == 1)
            out = oneVarIndefInt(IP, "z");
        end
    else
        if( varsx == 1)
            out = oneVarDefInt(IP, "x");
        elseif(varsy == 1)
            out = oneVarIndefInt(IP, "y");
        elseif(varsz == 1)
            out = oneVarIndefInt(IP, "z");
        end
    end
elseif( seri == 1 || sm == 1)
    %if it mentions series or sum
    out = sumSeries(IP);
end
