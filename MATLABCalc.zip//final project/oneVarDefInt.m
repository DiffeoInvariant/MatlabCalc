function [out] = oneVarDefInt(input, var)
%single-variable symbolic integration
contINF = contains(input, "to infinity");
contNEF = contains(input, "from negative infinity");
%finds equation and bounds
eqn = extractBetween(input, ":", ":");
a = extractBetween(input, "from", "to");
b = extractAfter(input,"to");
%if there is positive infinity mentioned
if (contINF==1 &&(contNEF ~= 1))
    %if x is the variable
    if( strcmp(var, "x") == 1)
        x = sym('x');
        out = int(eqn,x, a, Inf);
   %if y is the varible
    elseif( strcmp(var, "y") == 1)
        y =  sym('y');
        out = int(eqn,y, a, Inf);
        %if z is the variable
    elseif( strcmp(var, "z") == 1)
        z = sym('z');
        out = int(eqn,z, a, Inf);
    end
%if there is negative infinity mentioned    
elseif (contNEF == 1 &&(contINF ~= 1 ))
   %same as above
    if( strcmp(var, "x") == 1)
        x = sym('x');
        out = int(eqn,x, -Inf, b);
    elseif( strcmp(var, "y") == 1)
        y = sym('y');
        out = int(eqn,y, -Inf, b);
    elseif( strcmp(var, "z") == 1)
        z = sym('z');
        out = int(eqn,z, -Inf, b);
   end
%if both positive and negative infinities are mentioned   
elseif (contINF == 1 && contNEF == 1)
    %same as above   
    if( strcmp(var, "x") == 1)
        x = sym('x');
        out = int(eqn,x, -Inf, Inf);
    elseif( strcmp(var, "y") == 1)
        y = sym('y');
        out = int(eqn,y, -Inf, Inf);
    elseif( strcmp(var, "z") == 1)
        z = sym('z');
        out = int(eqn,z, -Inf, Inf);
    end
else
    %same as above
    if( strcmp(var, "x") == 1)
        x = sym('x');
        out = int(eqn,x, a, b);
    elseif( strcmp(var, "y") == 1)
        y = sym('y');
        out = int(eqn,y, a, b);
    elseif( strcmp(var, "z") == 1)
        z = sym('z');
        out = int(eqn,z, a, b);
    end
end