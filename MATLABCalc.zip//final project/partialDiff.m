function [out] = partialDiff(inProb,var)
eqn = extractBetween(inProb, ":", ":");
if( strcmp(var, "x") == 1)
    x = sym('x');
    out = diff(eqn,x);
    %takes partial derivative with respect to the variable
elseif( strcmp(var, "y") == 1)
    y = sym('y');
    out = diff(eqn,y);
    %takes partial derivative with respect to the variable
elseif( strcmp(var, "z") == 1)
    z = sym('z');
    out = diff(eqn,z);
    %takes partial derivative with respect to the variable
end