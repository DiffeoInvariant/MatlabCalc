function [out] = derivativerunner(eqn,var)

if( strcmp(var, "x") == 1)
    %finding variable x within string
    x = sym('x');
    %casting x
    out = diff(eqn,x);
    %using built in derivative function of equation and variable
elseif( strcmp(var, "y") == 1)
    y = sym('y');
    %casting y
    out = diff(eqn,y);
    %using built in derivative function of equation and variable
elseif( strcmp(var, "z") == 1)
    z = sym('z');
    %casting z
    out = diff(eqn,z);
    %using built in derivative function of equation and variable

end