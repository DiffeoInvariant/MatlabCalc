function [out] = derivative(input,var)
eqn = extractBetween(input, ":", ":");
%takes the derivative of the input with respect to the variable
if( strcmp(var, "x") == 1)
    x = sym('x');
    out = diff(eqn,x);
    %takes derivative of equation with respect to x
elseif( strcmp(var, "y") == 1)
    y = sym('y');
    out = diff(eqn,y);
    %takes derivative of equation with respect to y
elseif( strcmp(var, "z") == 1)
    z = sym('z');
    out = diff(eqn,z);
    %takes derivative of equation with respect to z
end