function [  ] = grapher(input)
%graphs a function
f = inline(char(input));
%casting variable types to work for 'plot'
x = -1:.1:1;
%going from -1 to 1
plot(x,f(x));
%plotting f(x) in terms of x
end

