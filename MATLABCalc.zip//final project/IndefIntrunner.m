function [out] = IndefIntrunner(input1)
%single variable integration
f = sym(input1);
%recasting variable type
syms x
%constructing variable x
out = int(f, x);
%using integral function of function f with respect to x
     
end
