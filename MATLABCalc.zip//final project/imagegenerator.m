function [ out ] = imagegenerator(  )
%outputs a random image
i = randi(20);
%random integer from 1 to 20
if i == 1
    out = imagesc(imread('kitty.jpg'));
elseif i == 2
    out = imagesc(imread('datboi.jpg'));
elseif i == 3
    out = imagesc(imread('dev.jpg'));
elseif i == 4
    out = imagesc(imread('united.jpg'));
elseif i == 5
    out = imagesc(imread('lionking.jpg'));
elseif i == 6
    out = imagesc(imread('puppers.jpg'));
elseif i == 7
    out = imagesc(imread('manny.jpg'));
elseif i == 8
    out = imagesc(imread('ryang.dms'));
elseif i == 9
    out = imagesc(imread('ryanr.jpg'));
elseif i == 10
    out = imagesc(imread('starwars.jpg'));
elseif i == 11
    out = imagesc(imread('harrypotter.jpg'));
elseif i == 12
    out = imagesc(imread('forrest.jpg'));
elseif i == 13
    out = imagesc(imread('mulan.jpg'));
elseif i == 14
    out = imagesc(imread('shrek.jpg'));
elseif i == 15
    out = imagesc(imread('csci.jpg'));
elseif i == 16
    out = imagesc(imread('hedgewater.jpg'));
elseif i == 17
    out = imagesc(imread('koala.jpg'));
elseif i == 18
    out = imagesc(imread('mathpen.png'));
elseif i == 19
    out = imagesc(imread('duck.jpg'));
elseif i == 20
    out = imagesc(imread('dolphin.jpg'));
else 
    out = imagesc(imread('trump.jpg'));
    %default image for faulty i ==
end
%for each number (i == ...) display a different image
end

