%Madison Dube and Zane Jakobs
%107347617  and 108525907
%CSCI 1320
%Final Project


clear;close all;clc;
choice = menu('Choose an Option', 'Exit Program', 'Do it For You', 'Function Help','Function Runner', ...
                'Graph a Function', 'Stress Relief');
            disp('LETS DO MATH')
%menu for all the things the code can do
while choice ~= 1
    %while choice is not exit program, keep looping through
    switch choice
        %switching choice
        case 0 
            disp('Please choose an Option')
            choice = menu('Choose an Option', 'Exit Program', 'Do it For You', 'Function Help','Function Runner', ...
                'Graph a Function', 'Stress Relief');
            %error message, loops back to menu
        case 2 
             disp('Enter your function with colons surrounding the equation--that is, write take the derivative of :x^2:, not take the derivative of x^2');
             fid = fopen('output.txt', 'w');
             in = fileread('projTest.txt');
             text = "The problem as entered is " +in + " and our answer is " + char(typeOfProblem(in));
             fprintf(fid, text);
             %creating and saving to text file
             disp(text);
             %displaying to screen
             prompt='Are you satisfied with this answer? (answer in " " )';
             %prompting user for input
             sat = input(prompt);
             %saving input as a stat
             sats(1).prob = in;
             sats(1).s = sat;
             %creating a forum for the comments
                
             
        case 3
              choice = menu('What do you need help with?', 'exit program', 'Limits', 'Derivatives', ...
                              'Anti-Derivatives', 'Integrals');
                          %problem help section, string functions
                          if choice ~= 1
                              %if the choice is not one, then go through
                              %menu
                              switch choice
                                  %switch choice
                                  case 0 
                                      disp('Please choose an option')
                                      choice = menu('What do you need help with?', 'exit program', 'Limits', 'Derivatives', ...
                                                'Anti-Derivatives', 'Integrals');
                                            %error for choosing not an
                                            %option, redisplay menu
                                  case 2
                                      limitHelp()
                                      %calls limit help function
                                      
                                  case 3
                                      derivativeHelp()
                                      %calls derivative help function
                                      
                                  case 4
                                      antiderivativeHelp()
                                      %calls antiderivative help function
                                      
                                  case 5 
                                      integralHelp()
                                      %calls integral help function
                              end
                          end
        case 4
            choice = menu('Which function would you like solved?', 'exit program', ...
                'Derivative', 'Definite Integral', 'Indefinite Integral');
            %menu for function runner
                if choice ~= 1
                    %when choice does not equal exit program
                              switch choice
                                  case 0 
                                      disp('Please choose an option')
                                      choice = menu('Which function would you like solved?', 'exit program', ...
                'Derivative', 'Definite Integral', 'Indefinite Integral');
            %error for choosing case 0
                                  case 2
                                      prompt = 'What is your equation? enter between " " \n';
                                      %asking user for equation input
                                      %between " "
                                      in = input(prompt);
                                      %saving input as a variable
                                      prompt1 = 'What is your variable? enter between " " \n';
                                      var = input(prompt1);
                                      %taking user variable and saving it
                                      %as var
                                      answer = derivativerunner(in, var);
                                      %calling derivative runner function
                                      disp(answer);
                                      %displaying answer to user
                                      
                                  case 3 
                                       prompt = 'What is your equation? enter between " " \n';
                                       %asking user for equation
                                       input1 = input(prompt);
                                       %saving equation as an input
                                      prompt1 = 'what is your lower bound? \n';
                                      a = input(prompt1);
                                      %saving user lower bound as a
                                      prompt2 ='what is your upper bound? \n';
                                       b = input(prompt2);
                                       %saving user upper bound as b
                                      answer = DefIntrunner(input1, a, b);
                                      %calling function for definite
                                      %integrals
                                      disp(answer);
                                      %Displaying the answer
                                      
                                  case 4
                                       prompt = 'What is your equation? please enter in terms of "x". Enter equation between " "\n';
                                      input1 = input(prompt);
                                      %having user enter equation and
                                      %saving it as an input
                                      answer = IndefIntrunner(input1);
                                      %calling indefinite integral runner
                                      disp(answer);
                                      %displaying answer
                                      disp('Remember to add "+c" to the end of our answer');
                                      %displaying warning for notation
                              end
                end
        case 5
            prompt = 'What is your equation? enter between " ". Enter in this format "2.*x + x.^2". enter "clc" when finished\n';
            %prompting user for input and also giving correct syntax for
            %entering 
            input = input(prompt);
            %saving input
            grapher(input);
            %calling grapher function of input
            
        case 6
            answer = imagegenerator();
            %calling imagegenerator function
    end
    choice = menu('Choose an Option', 'Exit Program', 'Do it For You', 'Function Help', 'Function Runner', ...
                'Graph a Function', 'Stress Relief');
            %repeating menu 
end

                                     