function [ out ] = integralHelp(  )
choice = menu('Choose an Option', 'Exit Program', 'indefinite Integrals', 'Definite Integrals');
%creating menu
while choice ~= 1
    %while choice is not exit, loop through
    switch choice
        case 0 
            disp('Error - please choose one of the options.')
           choice = menu('Choose an Option', 'Exit Program', 'indefinite Integrals', 'Definite Integrals');
           %display error message and menu
        case 2 
            disp('To take an indefinite integral, you first must set up the problem');
            disp('(for now we will use "S" as the integral sign)');
            disp('set up your integral as such: Sf(x)dx');
            disp('Then take the antiderivative of f(x)');
            disp('Once you have the antiderivative of f(x), add C to it');
            
            %explaining how to take indefinite integrals
            
            prompt='Is this what you wanted? To exit enter "0" (no = 0/yes = 1): ';
            %prompting the user for input
            x = input(prompt);
            %saving input as a variable
            if x==0
                choice = menu('Choose an Option', 'Exit Program', 'indefinite Integrals', 'Definite Integrals');
                %if 0 is enterred, go back to menu
            else
                imagesc(imread('indefint.jpg'))
                %if something other than 0, display image
            end
            
        case 3
            disp('To take the definite integral of an equation, you must have an upper and lower bound');
            disp('Take the integral the same as you would for an indefinite integral but do not add c');
            disp('Then plug in your upper bound for x into your antiderivative and subtract from it');
            disp('Your lower bound for x plugged into the antiderivative');
            %explaining how to take a definite integral
            
            prompt='Is this what you wanted? To exit enter "0" (no = 0/yes = 1): ';
            %prompting the user for input
            x = input(prompt);
            %saving user input for a variable
            if x==0
                choice = menu('Choose an Option', 'Exit Program', 'indefinite Integrals', 'Definite Integrals');
                %if 0, then go to menu
            else
                imagesc(imread('def_int.png'))
                %if other, then display image
            end        
    end
end

end

