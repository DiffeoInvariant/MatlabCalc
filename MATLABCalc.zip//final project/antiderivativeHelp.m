function [out] = antiderivativeHelp( )
disp('To take the antiderivative of a function, it helps to have your equation in: AX^n + BX^(n-1) + CX^(n-2)... form');
disp('Then it is a matter of working backwards. Use the product rule backwards by first adding one to n,');
disp('Then manipulate the coefficients so that when you derive your antiderivative,');
disp('it equals the initial equation');
%explaining how to take an antiderivative
out = imshow(imread('antiderive.jpg'));
%displaying an image with the explaination 

end

