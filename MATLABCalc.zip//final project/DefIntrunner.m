function [out] = DefIntrunner(input1, a, b)
%single-variable integration
f = sym(input1);
%recasting variable type
syms x
%constructing variable x
out = int(f, x, a, b);
%using integral function for function f with respect to x from a to b
 
end