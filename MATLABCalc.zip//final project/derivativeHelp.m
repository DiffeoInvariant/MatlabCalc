function [  ] = derivativeHelp( )
choice = menu('Choose an Option', 'Exit Program', 'Definition of Derivative', 'Power Rule',...,
    'Product Rule', 'Quotient Rule', 'Chain Rule');
%the menu for various derivative types
while choice ~= 1
    %looping through unless choice is exit program
    switch choice
        case 0 
            disp('Error - please choose one of the options.')
           % Display a menu and get a choice
           choice = menu('Choose an Option', 'Exit Program', 'Definition of Derivative', 'Power Rule',...,
    'Product Rule', 'Quotient Rule', 'Chain Rule');
%the menu repeated for the error statement
        case 2 
            disp('To solve a derivative using the limit definition, you must take the limit as h approaches zero of [(f(x+h)-f(x))/h]');
           %explaining limit definition
            prompt='Is this what you wanted? To exit enter "0" (no = 0/yes = 1): ';
            %prompting user for a 0 or 1
            x = input(prompt);
            %saving input
            if x==0
                choice = menu('Choose an Option', 'Exit Program', 'Definition of Derivative', 'Power Rule',...,
    'Product Rule', 'Quotient Rule', 'Chain Rule');
%if input is exit or no, go back to menu
            else
                imagesc(imread('limitdefinition.gif'))
                %if input is yes, then display image
            end
            
        case 3
            disp('To solve derivatives using the power rule, your problem should be in AX^n form');
            disp('Take the derivative by multiplying "n" by "AX" and subtracting one from "n" : n*AX^(n-1)');
            disp('repeat for each term in a polynomial');
            %explaining how to use power rule
            prompt='Is this what you wanted? To exit enter "0" (no = 0/yes = 1): ';
            %prompting user for input
            x = input(prompt);
            %saving input
            if x==0
                choice = menu('Choose an Option', 'Exit Program', 'Definition of Derivative', 'Power Rule',...,
    'Product Rule', 'Quotient Rule', 'Chain Rule');
%if answer is no or exit then redisplay menu
            else
                imagesc(imread('powerrule.jpg'))
                %if answer is yes or other then display image
            end
            
        case 4
            disp('The product rule for solving derivatives looks like this: UV" + U"V (" is the derivative)');
            disp('You take the derivative of the second term multiplied by the first term');
            disp('And then add the derivative of the first term multiplied by the second term');
            %explaining the product rule
           prompt='Is this what you wanted? To exit enter "0" (no = 0/yes = 1): ';
           %prompting user for input
            x = input(prompt);
            %saving input as a variable
            if x==0
                choice = menu('Choose an Option', 'Exit Program', 'Definition of Derivative', 'Power Rule',...,
    'Product Rule', 'Quotient Rule', 'Chain Rule');
%exiting if choice is 0 and going back to menu
            else
                imagesc(imread('productrule.png'))
                %showing image if input is not 0
            end
            
        case 5
            disp('To solve using the Quotient rule is similar to using the product rule');
            disp('take an equation in this form : V/U');
            disp('take the derivative by squaring the denominator, and then muliplying the denominator,');
            disp('by the derivative of the numerator and then subtracting from that the product of the');
            disp('derivative of the denominator multiplied by the numerator');
            disp('so that it looks like : (UV" - U"V)/U^2');
           %explaining quotient rule 
             prompt='Is this what you wanted? To exit enter "0" (no = 0/yes = 1): ';
             %prompting user for input
            x = input(prompt);
            %saving input as variable
            if x==0
                choice = menu('Choose an Option', 'Exit Program', 'Definition of Derivative', 'Power Rule',...,
    'Product Rule', 'Quotient Rule', 'Chain Rule');
%going back to menu if input is 0
            else
                imagesc(imread('quotientrule.gif'))
                %displaying image if input is not 0
            end
            
        case 6
            disp('To solve the derivative using the chain rule, you must follow a series of steps');
            disp('1: take the derivative of the outside, but leave the inside alone');
            disp('2: then multiply it all by the derivative of the inside');
            disp('example: U(V)   derived: U"(V) * V"');
            %chain rule explaination
            prompt='Is this what you wanted? To exit enter "0" (no = 0/yes = 1): ';
            %prompting the user for input
            x = input(prompt);
            %saving input as variable
            if x==0
                choice = menu('Choose an Option', 'Exit Program', 'Definition of Derivative', 'Power Rule',...,
    'Product Rule', 'Quotient Rule', 'Chain Rule');
%if input is 0, go back to menu
            else
                imagesc(imread('chainRule.jpg'))
                %not 0 then display image
            end
    end
end
end

