function [  ] = limitHelp(  )
choice = menu('Choose an Option', 'Exit Program', 'Taking a Limit', 'L^Hopitals Rule');
%help menu
while choice ~= 1
    switch choice
        case 0 
            disp('Error - please choose one of the options.')
           % Display a menu and get a choice
           choice = menu('Choose an Option', 'Exit Program', 'Taking a Limit', 'L^Hopitals Rule');
        case 2 
            disp('To take the limit as "x" approaches "a" of "f(x)", you could solve by plugging "a" in for "x"');
            disp('If you have a situation where plugging "a" in leads to a denominator of zero');
            disp('try multiplying "f(x)" by "(1/x)/(1/x)"');
            disp('If that does not work, see "L^Hopitals Rule"');
            %telling user how to solve
           
            prompt='Is this what you wanted? To exit enter "0" (no = 0/yes = 1): ';
            %prompting user for an input, yes or no
            x = input(prompt);
            %saving user input for x
            if x==0
                choice = menu('Choose an Option', 'Exit Program', 'Taking a Limit', 'L^Hopitals Rule');
                %going back to menu if that is not what user wanted
            else
                imagesc(imread('limitlim.gif'))
                %displaying an image explaining limits when user enters 1
            end
            
        case 3
            disp('To use L^Hopitals rule, you take the derivative of the numerator divided by the derivative of the denominator');
            disp('If you derived and the denomator still goes to zero, repeat the process until it clears');
            %telling user how to solve
            
            prompt='Is this what you wanted? To exit enter "0" (no = 0/yes = 1): ';
            %prompting user for a yes no answer
            x = input(prompt);
            %saving answer as a variable
            if x==0
                choice = menu('Choose an Option', 'Exit Program', 'Taking a Limit', 'L^Hopitals Rule');
                 %going back to menu if that is not what user wanted
            else
                imagesc(imread('lhopitals.jpg'))
                 %displaying an image explaining lhopitals when user enters 1
            end        
    end
end
end

